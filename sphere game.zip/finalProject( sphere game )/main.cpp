#include<windows.h>
#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif
#include <stdlib.h>

static int slices = 20; //number of sub polygons
static int stacks = 20;
static float tr=0,mov1=6.0,mov2 = 8.0, mov3=10.0 , mov4 =14.0 ;
static int left=0 , right=0 , up= 0 , down = 0;
static float sc=0;
static float way1=-3 ,way2=-3 ,way3=-3;
/* GLUT callback Handlers */
static void resize(int width, int height)
{
    const float ar = (float) width / (float) height;
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glFrustum(-ar, ar, -1.0, 1.0, 2.0, 100.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity() ;
}

static void display(void)
{
    const double t = glutGet(GLUT_ELAPSED_TIME) / 1000.0;
    const double a= t*90;
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glShadeModel(GL_FLAT);
    glPushMatrix();
    glColor3f(1.0,0.0,0.0); //color of my shapes (gray)
    glTranslated(1+tr,-1.7,-5);
    glRotatef(90,0,1,0);
    glRotatef((GLfloat)down,0.0,0.0,1.0);
    glRotatef((GLfloat)up,0.0,0.0,1.0);
    glRotatef((GLfloat)right,0.0,1.0,0.0);
    glRotatef((GLfloat)left,0.0,1.0,0.0);
    glutSolidSphere(0.6+sc,slices,stacks);

    glPopMatrix();

    glPushMatrix();
    glTranslatef(1,0,-6);
    glBegin(GL_POLYGON);    // the way
    glColor3f(0.6f, 0.6f, 0.6f);
    glVertex2f(-4,-7);
    glVertex2f(2,-7);
    glVertex2f(2,9);
    glVertex2f(-4,9);
    glEnd();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(2,way1,-5);
    glBegin(GL_POLYGON);    // the way
    glColor3f(256,256,256);
    glVertex2f(-2.2,4);
    glVertex2f(-2,4);
    glVertex2f(-2,5.5);
    glVertex2f(-2.2,5.5);
    glEnd();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(2,way2,-5);
    glBegin(GL_POLYGON);    // the way
    glColor3f(256,256,256);
    glVertex2f(-2.2,2.2);
    glVertex2f(-2,2.2);
    glVertex2f(-2,3.7);
    glVertex2f(-2.2,3.7);
    glEnd();
    glPopMatrix();
    glPushMatrix();
    glTranslatef(2,way3,-5);
    glBegin(GL_POLYGON);    // the way
    glColor3f(256,256,256);
    glVertex2f(-2.2,0);
    glVertex2f(-2,0);
    glVertex2f(-2,2);
    glVertex2f(-2.2,2);
    glEnd();
    glPopMatrix();
    glPushMatrix();  // the left teapot
    glColor3f(1.0f,0.2f,0.5f);
    glTranslatef(-1.4,mov1,-5);
    glRotatef(170,0,1,0);
    glutSolidTeapot(0.4+sc);
    glPopMatrix();
    glPushMatrix();    // the right teapot
    glColor3f(1.0f,0.2f,0.5f);
    glTranslatef(1.4,mov2,-5);
    glRotatef(170,0,1,0);
    glutSolidTeapot(0.4+sc);
    glPopMatrix();

    glPushMatrix();    // the left cube
    glColor3f(0.0f,0.6f,0.5f);
    //glTranslatef(-1,mov3,-5);
    glRotatef(130,1,0,0);
    glRotated(a,1,0,0);
    glutSolidCube(0.7+sc);
    glPopMatrix();
    glPushMatrix();    // the right cone
    glColor3f(0.0f,0.6f,0.5f);
    glTranslatef(1.1,mov3,-5);
    glRotatef(130,1,0,0);
    glRotated(a,1,0,0);
    glutSolidTorus(0.1+sc,0.3+sc,10,30);
    glPopMatrix();

    glutSwapBuffers();
}

static void key(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 27 :
    case 'q':
    case 'Q':
        exit(0);
        break;
    case 'z':
    case 'Z':
        slices++;
        stacks++;
        break;
    case 'x':
    case 'X':
        if (slices>3 && stacks>3)
        {
            slices--;
            stacks--;
        }
        break;
    case 'c':
    case 'C':
        if(sc<2)
            sc=sc+0.1;
        break;
    case 'v':
    case 'V':
        if(sc>0)
            sc= sc - 0.1;
        break;
    case 'w':
    case 'W':

        up=(up-40)%270; //move forward
        way1 = way1 -0.1;
        way2 = way2 -0.1;
        way3 = way3 -0.1;
        if(way1 < -4.0)
            way1 =-2;
        if(way2 < -4.0)
            way2=-2;
        if(way3 < -4.0)
            way3 = -2;
       mov3-=0.05;
       mov1-=0.05;
       mov2-=0.05;
       mov4-=0.05;
        break;

    case 's':
    case 'S':
        down=(down+40)%270; //move backward
        if(way1>0 && way2>0 && way3>0)
        {
            way1--;
            way2--;
            way3--;
        }
        break;
    case 'd':
    case 'D':
        right=(right+20)%180;
        if(tr<0.8)
            tr=tr+0.4;
        break;
    case 'a':
    case 'A':
        left=(left-20)%180;
        if(tr>-2.5)
            tr=tr-0.4;
        break;
    }

    glutPostRedisplay();
}

static void idle(void) //here put the thing you want it to move automatically
{
    mov1=mov1-0.006;
    if(mov1 < -2)mov1=6;
    mov2=mov2-0.006;
    if(mov2 < -2)mov2=6;
    mov3=mov3-0.006;
    if(mov3 < -2)mov3=6;
    mov4=mov4-0.006;
    if(mov4 < -2)mov4=6;
    glutPostRedisplay();
    //if(mov1 <up)exit(1);
}

const GLfloat light_ambient[]  = { 0.0f, 0.0f, 0.0f, 1.0f };
const GLfloat light_diffuse[]  = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_specular[] = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat light_position[] = { 2.0f, 5.0f, 5.0f, 0.0f };

const GLfloat mat_ambient[]    = { 0.7f, 0.7f, 0.7f, 1.0f };
const GLfloat mat_diffuse[]    = { 0.8f, 0.8f, 0.8f, 1.0f };
const GLfloat mat_specular[]   = { 1.0f, 1.0f, 1.0f, 1.0f };
const GLfloat high_shininess[] = { 100.0f };

/* Program entry point */

int main(int argc, char *argv[])
{
    glutInit(&argc, argv);
    glutInitWindowSize(1200,680);
    glutInitWindowPosition(70,30);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    glutCreateWindow("3D small game");
    glutReshapeFunc(resize);
    glutDisplayFunc(display);
    glutKeyboardFunc(key); // used for keyboard event glutMouseFunc() used for mouse event
    glutIdleFunc(idle);  //Used for animation and continuous update
    glClearColor(0,0.5,0,1);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);

    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    glEnable(GL_LIGHT0);
    glEnable(GL_NORMALIZE);
    glEnable(GL_COLOR_MATERIAL);
    glEnable(GL_LIGHTING);

    glLightfv(GL_LIGHT0, GL_AMBIENT,  light_ambient);
    glLightfv(GL_LIGHT0, GL_DIFFUSE,  light_diffuse);
    glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
    glLightfv(GL_LIGHT0, GL_POSITION, light_position);

    glMaterialfv(GL_FRONT, GL_AMBIENT,   mat_ambient);
    glMaterialfv(GL_FRONT, GL_DIFFUSE,   mat_diffuse);
    glMaterialfv(GL_FRONT, GL_SPECULAR,  mat_specular);
    glMaterialfv(GL_FRONT, GL_SHININESS, high_shininess);

    glutMainLoop();

    return EXIT_SUCCESS;
}
